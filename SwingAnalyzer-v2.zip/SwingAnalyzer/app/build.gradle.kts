plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.swing.analyzer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.swing.analyzer"
        minSdk = 29          // Android 10 이상
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // 항상 같은 키로 서명해야 새 버전을 덮어 설치할 수 있음(기록 유지). 개인 설치용 키입니다.
    signingConfigs {
        create("swing") {
            storeFile = file("swing-release.keystore")
            storePassword = "swing1234"
            keyAlias = "swing"
            keyPassword = "swing1234"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("swing")
        }
        debug {
            signingConfig = signingConfigs.getByName("swing")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    androidResources {
        noCompress += listOf("wasm", "task")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}

// ---------------------------------------------------------------------------
// 자세 인식 모델(MediaPipe)을 빌드할 때 한 번 내려받아 앱 안에 넣음
// → 설치 후에는 인터넷 없이도 분석 가능
// ---------------------------------------------------------------------------
val mpVersion = "0.10.14"
val mpBase = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@$mpVersion"
val mpFiles = mapOf(
    "vision_bundle.js" to "$mpBase/vision_bundle.mjs",
    "wasm/vision_wasm_internal.js" to "$mpBase/wasm/vision_wasm_internal.js",
    "wasm/vision_wasm_internal.wasm" to "$mpBase/wasm/vision_wasm_internal.wasm",
    "wasm/vision_wasm_nosimd_internal.js" to "$mpBase/wasm/vision_wasm_nosimd_internal.js",
    "wasm/vision_wasm_nosimd_internal.wasm" to "$mpBase/wasm/vision_wasm_nosimd_internal.wasm",
    "pose_landmarker_lite.task" to "https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task",
)
val mpDir = layout.projectDirectory.dir("src/main/assets/mp").asFile

val downloadMediapipe by tasks.registering {
    description = "MediaPipe 자세 인식 모델과 실행 파일을 assets/mp 에 내려받습니다."
    outputs.dir(mpDir)
    doLast {
        for ((name, url) in mpFiles) {
            val out = File(mpDir, name)
            if (out.exists() && out.length() > 0L) continue
            out.parentFile.mkdirs()
            println("다운로드: $url")
            val tmp = File(out.path + ".part")
            java.net.URI(url).toURL().openStream().use { input -> tmp.outputStream().use { input.copyTo(it) } }
            tmp.renameTo(out)
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadMediapipe) }
