package com.swing.analyzer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * 스윙 분석 앱.
 * 화면과 분석 로직은 assets/index.html(웹앱)에 있고, 이 액티비티는
 *  - 앱 안의 파일을 https://appassets.androidplatform.net 주소로 열어 카메라가 켜지게 하고
 *  - 카메라·마이크 권한, 갤러리 영상 선택, 갤러리 저장·공유를 안드로이드 기능으로 연결합니다.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var pendingPermission: PermissionRequest? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            val req = pendingPermission ?: return@registerForActivityResult
            pendingPermission = null
            grantAllowed(req)
        }

    private val pickVideos =
        registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            fileCallback?.onReceiveValue(uris.toTypedArray())
            fileCallback = null
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // 촬영 중 화면 꺼짐 방지
        WebView.setWebContentsDebuggingEnabled(true)

        web = WebView(this)
        web.setBackgroundColor(0xFF0D1512.toInt())
        setContentView(web)

        // 상태바·내비게이션바에 화면이 가리지 않도록
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", AssetHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                // 외부 링크는 브라우저로
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val need = mutableListOf<String>()
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) need += Manifest.permission.CAMERA
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) need += Manifest.permission.RECORD_AUDIO
                    if (need.all { has(it) }) {
                        grantAllowed(request)
                    } else {
                        pendingPermission?.deny()
                        pendingPermission = request
                        askPermissions.launch(need.toTypedArray())
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                pickVideos.launch("video/*")
                return true
            }
        }

        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.appBack ? window.appBack() : false)") { r ->
                    if (r != "true") finish()
                }
            }
        })

        if (savedInstanceState == null) {
            web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun grantAllowed(req: PermissionRequest) {
        val ok = req.resources.filter {
            when (it) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> has(Manifest.permission.CAMERA)
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> has(Manifest.permission.RECORD_AUDIO)
                else -> false
            }
        }
        if (ok.isEmpty()) req.deny() else req.grant(ok.toTypedArray())
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ 웹앱 ↔ 안드로이드 연결
    inner class Bridge {
        private val parts = ConcurrentHashMap<String, File>()

        /** 영상 전송 시작. 웹앱이 512KB씩 chunk()로 보낸 뒤 save() 또는 share() 호출 */
        @JavascriptInterface
        fun begin(name: String): String {
            val id = UUID.randomUUID().toString()
            val f = File(cacheDir, "part_$id")
            f.delete()
            parts[id] = f
            return id
        }

        @JavascriptInterface
        fun chunk(id: String, b64: String) {
            parts[id]?.appendBytes(Base64.decode(b64, Base64.NO_WRAP))
        }

        /** 갤러리(Movies/SwingAnalysis)에 저장 */
        @JavascriptInterface
        fun save(id: String, name: String, mime: String): Boolean {
            val f = parts.remove(id) ?: return false
            return try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, safeName(name))
                    put(MediaStore.Video.Media.MIME_TYPE, mime.ifBlank { "video/mp4" })
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SwingAnalysis")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                true
            } catch (e: Exception) {
                false
            } finally {
                f.delete()
            }
        }

        /** 카카오톡 등으로 공유 */
        @JavascriptInterface
        fun share(id: String, name: String, mime: String, text: String) {
            val f = parts.remove(id) ?: return
            val dir = File(cacheDir, "share").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val out = File(dir, safeName(name))
            if (!f.renameTo(out)) {
                f.copyTo(out, overwrite = true)
                f.delete()
            }
            val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.files", out)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime.ifBlank { "video/mp4" }
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            runOnUiThread { startActivity(Intent.createChooser(send, "스윙 영상 공유")) }
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("swing", text))
            }
        }

        @JavascriptInterface
        fun toast(text: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, text, Toast.LENGTH_SHORT).show() }
        }

        private fun safeName(n: String) = n.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    }
}

/** 앱 안의 assets 파일을 정확한 형식(MIME)으로 웹뷰에 전달 */
class AssetHandler(private val ctx: Context) : WebViewAssetLoader.PathHandler {
    override fun handle(path: String): WebResourceResponse? {
        return try {
            val mime = when (path.substringAfterLast('.', "").lowercase()) {
                "html", "htm" -> "text/html"
                "js", "mjs" -> "text/javascript"
                "css" -> "text/css"
                "json" -> "application/json"
                "wasm" -> "application/wasm"
                "png" -> "image/png"
                "svg" -> "image/svg+xml"
                else -> "application/octet-stream"
            }
            val enc = if (mime.startsWith("text/") || mime == "application/json") "utf-8" else null
            WebResourceResponse(mime, enc, ctx.assets.open(path)).apply {
                responseHeaders = mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache")
            }
        } catch (e: IOException) {
            null
        }
    }
}
